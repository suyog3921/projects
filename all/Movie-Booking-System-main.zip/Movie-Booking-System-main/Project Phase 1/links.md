
DRAW.IO WIREFRAME

https://app.diagrams.net/#G1bKi85OpP1OKQvkqeUb775X-hLuBU4QnN#%7B%22pageId%22%3A%2244ZaED6bbbjGjywIT5Lh%22%7D


LUCID.COM
ER DIAGRAM

https://lucid.app/lucidchart/7a24c464-ecfb-4c96-ae93-bdb6b831d2f4/edit?invitationId=inv_7c937148-eefa-4e88-a952-c77784b0a8c9&page=0_0#

