const config = {
    url: 'http://localhost:8080',
}
export default config;