import Navbar from "../components/navbar/Navbar"
import Footer from "../components/footer/Footer"
function MovieDetails(){
    return(
        <div>
            <Navbar />
            <h2 className="page-header">MovieDetails</h2>
            <Footer/>
        </div>
    )
}

export default MovieDetails