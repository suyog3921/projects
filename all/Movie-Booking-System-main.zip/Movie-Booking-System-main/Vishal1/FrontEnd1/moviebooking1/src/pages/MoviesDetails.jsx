import Navbar from "./Navbar"
import Footer from "./Footer"
function MovieDetails(){
    return(
        <div>
            <Navbar />
            <h2 className="page-header">MovieDetails</h2>
            <Footer/>
        </div>
    )
}

export default MovieDetails