import Navbar from "./Navbar"
import Footer from "./Footer"
function MovieList(){
    return(
        <div>
            <Navbar/>
            <h2 className="page-header">MovieList</h2>
            <Footer/>
        </div>
    )
}

export default MovieList