import Navbar from "./Navbar"
import Footer from "./Footer"
function MovieBooking(){
    return(
        <div>
            <Navbar/>
            <h2 className="page-header">MovieBooking</h2>
            <Footer/>
        </div>
    )
}

export default MovieBooking