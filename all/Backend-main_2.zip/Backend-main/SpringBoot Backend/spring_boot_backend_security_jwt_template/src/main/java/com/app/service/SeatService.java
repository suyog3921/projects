package com.app.service;

import java.util.List;


import com.app.dto.SeatDTO;

public interface SeatService {

//	void updateSeats(List<SeatDTO> seats);

}
