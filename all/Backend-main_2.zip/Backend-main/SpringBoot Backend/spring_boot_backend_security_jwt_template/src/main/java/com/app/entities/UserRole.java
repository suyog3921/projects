package com.app.entities;

public enum UserRole {
	ROLE_ADMIN, ROLE_USER
}
